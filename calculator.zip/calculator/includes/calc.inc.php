<?php
include 'class-autoload.inc.php';

$oper = $_POST["oper"];
$number1 = $_POST["number1"];
$number2 = $_POST["number2"];

$calc = new Calc($oper,$number1,$number2);

try {
    echo $calc->calculator();
} catch (TypeError $e) {
    echo "Error!: " .$e->getMessage();
}

?>