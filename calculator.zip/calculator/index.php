<?php

 include 'includes/class-autoload.inc.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Calculator</title>
</head>
<body>

<form action="includes/calc.inc.php" method = "post">

    <p>Calculator</p>
    <input type= "number" name="number1" placeholder="First Number">
    <select name="oper" >
      <option value="+"> + </option>
      <option value="-"> - </option>
      <option value="/">/</option>
      <option value="*">*</option>
    </select>
    <input type="number" name="number2" placeholder="number2">
    <button type="submit" name="submit">  Calculate</button>

</form>

</body>
</html>