<?php

class Calc{
    public $operator;
    public $number1;
    public $number2;


    public function __construct(string $one, int $two, int $three){
        $this->operator = $one;
        $this->number1 = $two;
        $this->number2 = $three;
    }


    public function calculator(){
     switch ($this->operator) {
         case '+':
            $result = $this->number1 + $this->number2;
            return $result;             
            break;
        case '-':
            $result = $this->number1 - $this->number2;
            return $result;             
            break;
        case '/':    
             $result = $this->number1 / $this->number2;
             return $result;             
             break;
        case '*':    
             $result = $this->number1 * $this->number2;
             return $result;             
             break;

     }
    }

}